package com.harsh.applock

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

object Prefs {
    private const val FILE = "applock_local"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun locked(c: Context): Set<String> = p(c).getStringSet("locked_packages", emptySet())?.toSet() ?: emptySet()
    fun setLocked(c: Context, packageName: String, enabled: Boolean) {
        val current = locked(c).toMutableSet()
        if (enabled) current.add(packageName) else current.remove(packageName)
        p(c).edit().putStringSet("locked_packages", current).apply()
    }
    fun hasPin(c: Context) = p(c).contains("pin_hash") && p(c).contains("pin_salt")
    fun savePin(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(c).edit().putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", hash(pin, salt)).apply()
    }
    fun verifyPin(c: Context, pin: String): Boolean {
        val saltString = p(c).getString("pin_salt", null) ?: return false
        val expected = p(c).getString("pin_hash", null) ?: return false
        val salt = Base64.decode(saltString, Base64.NO_WRAP)
        return MessageDigest.isEqual(expected.toByteArray(), hash(pin, salt).toByteArray())
    }
    private fun hash(pin: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        return Base64.encodeToString(digest.digest(pin.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }
    fun setBypass(c: Context, packageName: String) = p(c).edit().putString("bypass_package", packageName).putLong("bypass_at", System.currentTimeMillis()).apply()
    fun consumeBypass(c: Context, packageName: String): Boolean {
        val prefs = p(c)
        val saved = prefs.getString("bypass_package", null)
        val at = prefs.getLong("bypass_at", 0L)
        if (saved == packageName && System.currentTimeMillis() - at < 12_000L) {
            prefs.edit().remove("bypass_package").remove("bypass_at").apply()
            return true
        }
        return false
    }
}
