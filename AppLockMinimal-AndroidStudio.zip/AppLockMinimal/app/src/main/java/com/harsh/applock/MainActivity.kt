package com.harsh.applock

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Space
import android.widget.Switch
import android.widget.TextView
import androidx.biometric.BiometricManager

class MainActivity : Activity() {
    private val background = Color.rgb(9, 12, 15)
    private val surface = Color.rgb(20, 26, 31)
    private val surfaceRaised = Color.rgb(28, 35, 41)
    private val accent = Color.rgb(155, 238, 193)
    private val muted = Color.rgb(155, 166, 175)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background
        window.navigationBarColor = background
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 30)
            setBackgroundColor(background)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(label("APPLOCK  /  CONTROL ROOM"))
        root.addView(TextView(this).apply {
            text = "Your apps,\nunder your control."
            textSize = 32f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "Private protection with biometric or PIN unlock."
            textSize = 15f
            setTextColor(muted)
            setPadding(0, 9, 0, 24)
        })

        val watching = isAccessibilityEnabled()
        root.addView(securityCard(watching), LinearLayout.LayoutParams(-1, -2))
        root.addView(space(16))
        root.addView(sectionTitle("UNLOCK METHODS"))
        root.addView(settingRow(
            title = "Face & fingerprint",
            detail = biometricStatus(),
            actionLabel = "Check",
            action = { showBiometricInfo() }
        ))
        root.addView(space(8))
        root.addView(settingRow(
            title = if (Prefs.hasPin(this)) "PIN configured" else "Set your PIN",
            detail = if (Prefs.hasPin(this)) "A 4–8 digit fallback is ready." else "Set a PIN for offline fallback unlock.",
            actionLabel = if (Prefs.hasPin(this)) "Change" else "Set up",
            action = { showPinDialog() }
        ))
        root.addView(space(22))
        root.addView(sectionTitle("PROTECTED APPS"))
        root.addView(TextView(this).apply {
            text = "Choose which app launches require an unlock."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 6, 0, 12)
        })

        val lockedApps = Prefs.locked(this)
        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }
        if (apps.isEmpty()) {
            root.addView(TextView(this).apply { text = "No launchable apps found."; setTextColor(muted); textSize = 14f })
        }
        apps.forEach { (packageName, name) -> root.addView(appRow(packageName, name, packageName in lockedApps)) }
        root.addView(space(14))
        root.addView(TextView(this).apply {
            text = "AppLock detects selected app launches through Android’s accessibility service. It does not read screen content. This is a best-effort gate; Android system settings, force-stop, safe mode, and permission changes may bypass it."
            textSize = 12f
            lineSpacingExtra = 4f
            setTextColor(Color.rgb(113, 125, 134))
        })
    }

    private fun securityCard(watching: Boolean): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 18)
            background = rounded(surface, 24)
        }
        val state = if (watching) "PROTECTION ACTIVE" else "SETUP REQUIRED"
        val stateColor = if (watching) accent else Color.rgb(255, 201, 118)
        card.addView(TextView(this).apply {
            text = "●  $state"
            textSize = 12f
            letterSpacing = 0.09f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(stateColor)
        })
        card.addView(TextView(this).apply {
            text = if (watching) "Watching selected apps" else "Turn on app monitoring"
            textSize = 21f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setPadding(0, 9, 0, 4)
        })
        card.addView(TextView(this).apply {
            text = if (watching) "AppLock will ask for an unlock when a protected app opens." else "Enable the AppLock accessibility service to protect app launches."
            textSize = 14f
            setTextColor(muted)
        })
        card.addView(space(14))
        card.addView(primaryButton(if (watching) "Review app monitoring" else "Enable app monitoring") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        return card
    }

    private fun settingRow(title: String, detail: String, actionLabel: String, action: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 16, 14, 16)
            background = rounded(surfaceRaised, 19)
        }
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(TextView(this).apply { text = title; textSize = 16f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(Color.WHITE) })
        copy.addView(TextView(this).apply { text = detail; textSize = 13f; setTextColor(muted); setPadding(0, 4, 0, 0) })
        row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = actionLabel
            textSize = 13f
            isAllCaps = false
            setTextColor(accent)
            background = rounded(Color.rgb(39, 52, 48), 13)
            setOnClickListener { action() }
        })
        return row
    }

    private fun appRow(packageName: String, name: String, locked: Boolean): LinearLayout {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(18, 14, 10, 14)
            background = rounded(surface, 18)
        }
        row.addView(TextView(this).apply {
            text = name
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply {
            isChecked = locked
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(accent, Color.rgb(95, 107, 117)))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(Color.rgb(52, 84, 67), Color.rgb(47, 55, 62)))
            setOnCheckedChangeListener { _, enabled -> Prefs.setLocked(this@MainActivity, packageName, enabled) }
        })
        val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
        row.layoutParams = params
        return row
    }

    private fun biometricStatus(): String = when (BiometricManager.from(this)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
        BiometricManager.BIOMETRIC_SUCCESS -> "Face or fingerprint is ready on this device."
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "Add face or fingerprint in Android settings."
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "No supported biometric hardware found."
        else -> "Biometric hardware is temporarily unavailable."
    }

    private fun showBiometricInfo() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Face & fingerprint unlock")
            .setMessage("AppLock uses Android’s secure system biometric prompt. If your device has an enrolled fingerprint or face unlock, either can authenticate. AppLock never sees or stores biometric data.")
            .setPositiveButton("Got it", null)
            .show()
    }

    private fun showPinDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "4–8 digit PIN"
            setSingleLine(true)
        }
        val box = LinearLayout(this).apply { setPadding(28, 8, 28, 0); addView(input) }
        android.app.AlertDialog.Builder(this)
            .setTitle(if (Prefs.hasPin(this)) "Change PIN" else "Set your PIN")
            .setMessage("This PIN is the fallback when biometric unlock is unavailable.")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val pin = input.text.toString()
                        if (pin.length !in 4..8 || pin.any { !it.isDigit() }) {
                            input.error = "Use 4–8 digits"
                            return@setOnClickListener
                        }
                        Prefs.savePin(this, pin)
                        dialog.dismiss()
                        render()
                    }
                }
                dialog.show()
            }
    }

    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == packageName && it.resolveInfo.serviceInfo.name == AppWatchService::class.java.name
        }
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 11f
        letterSpacing = 0.14f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(accent)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        letterSpacing = 0.12f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(accent)
    }

    private fun primaryButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.rgb(10, 19, 14))
        background = rounded(accent, 16)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun space(height: Int) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, height) }
}
