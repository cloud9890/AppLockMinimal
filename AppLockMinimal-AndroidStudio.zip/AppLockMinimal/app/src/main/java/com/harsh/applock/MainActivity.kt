package com.harsh.applock

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 5, 5)
    private val panel = Color.rgb(23, 23, 23)
    private val mint = Color.rgb(184, 246, 208)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }
    private lateinit var root: LinearLayout
    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 30, 22, 24); setBackgroundColor(bg) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        root.addView(text("AppLock", 30, Color.WHITE, true))
        root.addView(text("Minimal protection. Maximum privacy.", 14, 0xFF999999.toInt()))
        gap(22)
        val hasPin = Prefs.hasPin(this)
        val pinButton = button(if (hasPin) "Change PIN" else "Set up PIN") { showPinDialog() }
        root.addView(pinButton)
        gap(10)
        val enabled = isAccessibilityEnabled()
        root.addView(button(if (enabled) "Accessibility protection: enabled" else "Enable app monitoring") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(text("Android requires you to enable the AppLock accessibility service manually. It detects selected app launches; it does not read screen content.", 12, 0xFF999999.toInt()).apply { setPadding(2, 8, 2, 8) })
        gap(12)
        root.addView(text("YOUR APPS", 12, mint, true))
        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }.filter { it.first != packageName }.sortedBy { it.second.lowercase() }
        val locked = Prefs.locked(this)
        if (apps.isEmpty()) root.addView(text("No launchable apps found.", 14, Color.WHITE))
        apps.forEach { (pkg, name) ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(14, 8, 10, 8); background = rounded(panel, 16) }
            val label = TextView(this).apply { text = name; textSize = 15f; setTextColor(Color.WHITE); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            val toggle = Switch(this).apply { buttonTintList = null; isChecked = pkg in locked; setOnCheckedChangeListener { _, checked -> Prefs.setLocked(this@MainActivity, pkg, checked) } }
            row.addView(label); row.addView(toggle)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 8; root.addView(row, lp)
        }
        gap(12)
        root.addView(text("Note: This prototype is a best-effort app-launch gate, not tamper-proof. Android system screens, force-stop, safe mode, and permission changes may bypass it. Do not rely on it as the sole protection for sensitive data.", 12, 0xFF888888.toInt()))
    }
    private fun showPinDialog() {
        val input = EditText(this).apply { inputType = 2; hint = "Enter a 4–8 digit PIN"; setTextColor(Color.WHITE); setHintTextColor(0xFF888888.toInt()) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0); addView(input) }
        android.app.AlertDialog.Builder(this).setTitle("Set AppLock PIN").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Save", null).create().also { dialog ->
                dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener {
                    val pin = input.text.toString()
                    if (pin.length !in 4..8 || pin.any { !it.isDigit() }) { input.error = "Use 4–8 digits"; return@setOnClickListener }
                    Prefs.savePin(this, pin); dialog.dismiss(); render()
                } }
                dialog.show()
            }
    }
    private fun isAccessibilityEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == packageName && it.resolveInfo.serviceInfo.name == AppWatchService::class.java.name
        }
    }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setTextColor(if (s.startsWith("Enable")) Color.BLACK else Color.WHITE); if (s.startsWith("Enable")) background = rounded(mint, 14); setOnClickListener { action() } }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }
    private fun gap(px: Int) { root.addView(View(this), LinearLayout.LayoutParams(1, px)) }
}
