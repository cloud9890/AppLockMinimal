package com.harsh.applock

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

class LockActivity : FragmentActivity() {
    private val background = Color.rgb(9, 12, 15)
    private val surface = Color.rgb(20, 26, 31)
    private val accent = Color.rgb(155, 238, 193)
    private val muted = Color.rgb(155, 166, 175)
    private var targetPackage = ""
    private lateinit var pinField: EditText
    private lateinit var status: TextView
    private var biometricPrompt: BiometricPrompt? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = background
        window.navigationBarColor = background
        targetPackage = intent.getStringExtra("target_package") ?: ""
        render()
        showBiometricPrompt()
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        targetPackage = intent.getStringExtra("target_package") ?: targetPackage
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(this@LockActivity.background)
        }
        root.addView(label("APPLOCK · PRIVATE SPACE"))
        root.addView(space(18))
        root.addView(TextView(this).apply {
            text = "This app is locked"
            textSize = 30f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Verify your identity to return to the app."
            textSize = 15f
            setTextColor(muted)
            setPadding(0, 8, 0, 0)
        })
        root.addView(space(32))

        val biometricCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            background = rounded(surface, 24)
        }
        biometricCard.addView(TextView(this).apply {
            text = "BIOMETRIC UNLOCK"
            textSize = 12f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.12f
            setTextColor(accent)
        })
        biometricCard.addView(TextView(this).apply {
            text = "Face or fingerprint"
            textSize = 21f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 4)
        })
        biometricCard.addView(TextView(this).apply {
            text = biometricDescription()
            textSize = 14f
            setTextColor(muted)
        })
        biometricCard.addView(space(16))
        biometricCard.addView(primaryButton("Verify with biometrics") { showBiometricPrompt() })
        root.addView(biometricCard, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "OR USE YOUR PIN"
            textSize = 12f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            letterSpacing = 0.12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 12)
        })
        pinField = EditText(this).apply {
            hint = "Enter your PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(muted)
            textSize = 17f
            gravity = Gravity.CENTER
            setSingleLine(true)
            background = rounded(surface, 18)
            setPadding(20, 14, 20, 14)
        }
        root.addView(pinField, LinearLayout.LayoutParams(-1, -2))
        root.addView(space(10))
        root.addView(secondaryButton("Unlock with PIN") {
            if (Prefs.verifyPin(this, pinField.text.toString())) {
                unlockTarget()
            } else {
                status.text = "That PIN does not match. Try again."
                pinField.text.clear()
            }
        })
        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 158, 158))
            setPadding(0, 16, 0, 0)
        }
        root.addView(status)
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "Your biometric information stays on this device."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(112, 124, 133))
        })
        setContentView(root)
    }

    private fun biometricDescription(): String = when (BiometricManager.from(this)
        .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
        BiometricManager.BIOMETRIC_SUCCESS -> "Use an enrolled face or fingerprint."
        BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> "Set up face or fingerprint in Android settings, or use your PIN."
        BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> "This device has no supported biometric sensor. Use your PIN."
        BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> "Biometric hardware is temporarily unavailable. Use your PIN."
        else -> "Biometric verification is unavailable. Use your PIN."
    }

    private fun showBiometricPrompt() {
        when (BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
            BiometricManager.BIOMETRIC_SUCCESS -> Unit
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                if (::status.isInitialized) status.text = "Add face or fingerprint in Android settings, then try again."
                return
            }
            else -> {
                if (::status.isInitialized) status.text = "Biometric unlock is unavailable on this device. Use your PIN."
                return
            }
        }

        biometricPrompt?.cancelAuthentication()
        biometricPrompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    unlockTarget()
                }

                override fun onAuthenticationError(errorCode: Int, errorMessage: CharSequence) {
                    super.onAuthenticationError(errorCode, errorMessage)
                    if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON && ::status.isInitialized) {
                        status.text = errorMessage
                    }
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    if (::status.isInitialized) status.text = "Biometric not recognized. Try again or use your PIN."
                }
            })
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock AppLock")
            .setSubtitle("Use your face or fingerprint")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        biometricPrompt?.authenticate(promptInfo)
    }

    private fun unlockTarget() {
        Prefs.setBypass(this, targetPackage)
        finish()
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 11f
        letterSpacing = 0.14f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(accent)
    }

    private fun primaryButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.rgb(10, 19, 14))
        background = rounded(accent, 16)
        setOnClickListener { action() }
    }

    private fun secondaryButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(43, 51, 59), 16)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun space(height: Int) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, height) }

    override fun onDestroy() {
        biometricPrompt?.cancelAuthentication()
        super.onDestroy()
    }
}
