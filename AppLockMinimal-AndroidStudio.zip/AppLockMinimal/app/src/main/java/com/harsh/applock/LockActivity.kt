package com.harsh.applock

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.biometrics.BiometricPrompt
import android.os.Bundle
import android.os.CancellationSignal
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import java.util.concurrent.Executor

class LockActivity : Activity() {
    private val mint = Color.rgb(184, 246, 208)
    private var target = ""
    private lateinit var pin: EditText
    private lateinit var status: TextView
    private var cancelSignal: CancellationSignal? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        target = intent.getStringExtra("target_package") ?: ""
        showUi()
        tryBiometric()
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); target = intent.getStringExtra("target_package") ?: target; showUi() }
    private fun showUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(30, 30, 30, 30); setBackgroundColor(Color.rgb(5,5,5)) }
        root.addView(TextView(this).apply { text = "App locked"; textSize = 28f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        root.addView(TextView(this).apply { text = "Authenticate to continue"; textSize = 14f; setTextColor(0xFF999999.toInt()); gravity = Gravity.CENTER; setPadding(0, 10, 0, 24) })
        pin = EditText(this).apply { hint = "Enter PIN"; inputType = 2; setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt()); gravity = Gravity.CENTER; setSingleLine(true) }
        root.addView(pin, LinearLayout.LayoutParams(-1, -2))
        val unlock = Button(this).apply { text = "Unlock"; setTextColor(Color.BLACK); setBackgroundColor(mint); setOnClickListener { if (Prefs.verifyPin(this@LockActivity, pin.text.toString())) unlockTarget() else { status.text = "Incorrect PIN"; pin.text.clear() } } }
        root.addView(unlock, LinearLayout.LayoutParams(-1, -2))
        val biometric = Button(this).apply { text = "Use fingerprint"; setOnClickListener { tryBiometric() } }
        root.addView(biometric, LinearLayout.LayoutParams(-1, -2))
        status = TextView(this).apply { text = ""; setTextColor(0xFFFF7777.toInt()); gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }
        root.addView(status)
        setContentView(root)
    }
    private fun tryBiometric() {
        if (android.os.Build.VERSION.SDK_INT < 28) return
        try {
            val executor = Executor { it.run() }
            val prompt = BiometricPrompt.Builder(this).setTitle("Unlock app").setSubtitle("Verify your identity").setNegativeButton("Use PIN", executor) { _, _ -> }.build()
            cancelSignal = CancellationSignal()
            prompt.authenticate(cancelSignal, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) { runOnUiThread { unlockTarget() } }
                override fun onAuthenticationFailed() { runOnUiThread { status.text = "Fingerprint not recognized" } }
            })
        } catch (_: Exception) { status.text = "Fingerprint unavailable. Use PIN." }
    }
    private fun unlockTarget() { Prefs.setBypass(this, target); finish() }
    override fun onDestroy() { cancelSignal?.cancel(); super.onDestroy() }
}
