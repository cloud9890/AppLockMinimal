package com.harsh.applock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppWatchService : AccessibilityService() {
    private var lastPackage: String? = null
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == "com.android.systemui") return
        if (pkg == packageName || pkg == lastPackage) return
        lastPackage = pkg
        if (pkg !in Prefs.locked(this)) return
        if (Prefs.consumeBypass(this, pkg)) return
        if (!Prefs.hasPin(this)) return
        val intent = Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("target_package", pkg)
        }
        try { startActivity(intent) } catch (_: Exception) { }
    }

    override fun onInterrupt() { }
}
