# AppLock Minimal (Android / Kotlin)

A minimalist AMOLED-black app-lock prototype for Android 8.0+ with local PIN settings, Android biometric prompt, selectable launchable apps, and an explicitly user-enabled AccessibilityService app-launch gate.

## Build an APK

1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.
5. Install it on the phone, open AppLock, set a PIN, and enable **AppLock app protection** under Android Accessibility settings.
6. Return to AppLock and select the apps to protect.

## Important limitations

- This is a prototype and has not been compiled or tested on a physical Galaxy S25 in this environment.
- Accessibility launch detection is best-effort, not a secure OS-level app sandbox. Android may restrict background activity launches, and app switching can race. Force-stop, safe mode, permission revocation, and system UI may bypass protection.
- For production-grade protection, test on the exact One UI release and consider Samsung Knox/managed-device APIs where available. Do not claim parity with Secure Folder.
- PIN hash is salted SHA-256 for this prototype; production authentication should use a stronger, iterated password KDF and robust retry throttling.
- Fingerprint uses Android's system biometric prompt. Some Android releases may require migrating from deprecated platform APIs to AndroidX Biometric.
- The service only observes window/package transitions and does not retrieve window content.
